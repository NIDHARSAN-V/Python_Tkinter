from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
import mysql.connector
from DB import Database

con=mysql.connector.connect(host="localhost", user="root", passwd="4728", database="employee")
res=con.cursor()

db=Database()
win = Tk()
win.title("EMPLOYEE MANAGEMENT SYSTEM")
win.geometry("1918x1080+0+0")

bg_image = Image.open("03.jpg")
bg_image = bg_image.resize((1918, 1080))  
bg_photo = ImageTk.PhotoImage(bg_image)


bg_label = Label(win, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

win.state("zoomed")

name=StringVar()
age=StringVar()
doj=StringVar()
gender=StringVar()
email=StringVar()
ph=StringVar()
address=StringVar()

Entries_Frame=Frame(win)
Entries_Frame.pack(side=TOP)
title=Label(Entries_Frame, text="EMPLOYEE MANAGEMENT SYSTEM", font=("Tahoma",35,"bold"),bg="#4cd0ff")
title.grid(row=0, columnspan=2)

#Entries_Frame1 = Frame(win)
#Entries_Frame1.pack()
lblName=Label(text="NAME :", font=("Tahoma",18,"bold"),bg="#4cd0ff")
lblName.place(x=100, y=150)

txtName = Entry(textvariable=name, font=("Tahoma",18,"bold"),bg="white")
txtName.place(x=250, y=150)

lblage=Label(text="AGE :", font=("Tahoma",18,"bold"),bg="#4cd0ff")
lblage.place(x=760, y=150)

txtage = Entry(textvariable=age, font=("Tahoma",18,"bold"),bg="white")
txtage.place(x=950, y=150)

lbldoj=Label(text="DOJ :", font=("Tahoma",18,"bold"),bg="#4cd0ff")
lbldoj.place(x=100, y=210)

txtdoj = Entry(textvariable=doj, font=("Tahoma",18,"bold"),bg="white")
txtdoj.place(x=250, y=210)

lblGEN=Label(text="GENDER :", font=("Tahoma",18,"bold"),bg="#4cd0ff")
lblGEN.place(x=760, y=210)

txtGEN = ttk.Combobox(textvariable=gender, font=("Tahoma",18,"bold"), width=19,state="readonly")
txtGEN['values']=('Male','Female')
txtGEN.place(x=950, y=210)

lblEM=Label(text="EMAIL :", font=("Tahoma",18,"bold"),bg="#4cd0ff")
lblEM.place(x=100, y=270)

txtEM = Entry(textvariable=email, font=("Tahoma",18,"bold"),bg="white")
txtEM.place(x=250, y=270)

lblPH=Label(text="PH NO :", font=("Tahoma",18,"bold"),bg="#4cd0ff")
lblPH.place(x=760, y=270)

txtPH = Entry(textvariable=ph, font=("Tahoma",18,"bold"),bg="white")
txtPH.place(x=950, y=270)


lblADD=Label(text="ADDRESS :", font=("Tahoma",18,"bold"),bg="#4cd0ff")
lblADD.place(x=100, y=330)

txtADD =Text(font=("Tahoma",18,"bold"),width=67, height=5)
txtADD.place(x=250, y=330)

def getdata(event):
    selectrow = tv.focus()
    data = tv.item(selectrow)
    global row
    row = data["values"]
    name.set(row[1])
    age.set(row[2])
    doj.set(row[3])
    email.set(row[4])
    gender.set(row[5])
    ph.set(row[6])
    txtADD.delete(1.0,END)
    txtADD.insert(END,row[7])
def disp_all():
    tv.delete(*tv.get_children())
    for row in db.fetch():
        tv.insert("",END,values=row)
def add_emp():
    if txtName.get()=="" or txtage.get()=="" or txtdoj.get()=="" or txtEM.get()=="" or txtGEN.get()=="" or txtPH.get()=="" or txtADD.get(1.0,END)=="":
        messagebox.showerror("Error in input","Please fill the details")
        return
    db.insert(txtName.get(),txtage.get(),txtdoj.get(),txtEM.get(),txtGEN.get(),txtPH.get(),txtADD.get(1.0,END))
    messagebox.showinfo("Sucess", "Insertion sucessful")
    cl_emp()
    disp_all()
def upd_emp():
    if txtName.get()==""or txtage.get()==""or txtdoj.get()==""or txtEM.get()==""or txtGEN.get()==""or txtPH.get()==""or txtADD.get(1.0,END)=="":
        messagebox.showerror("Error in input","Please fill the details")
        return
    db.update(row[0], txtName.get(), txtage.get(), txtdoj.get(), txtEM.get(), txtGEN.get(), txtPH.get(), txtADD.get(1.0,END))
    messagebox.showinfo("Success", "Updation successful")
    cl_emp()
    disp_all()
def del_emp():
    db.remove(row[0])
    cl_emp()
    disp_all()
    messagebox.showinfo("Success!", "Deletion Successful")
def cl_emp():
    name.set("")
    age.set("")
    doj.set("")
    gender.set("")
    email.set("")
    ph.set("")
    txtADD.delete(1.0,END)


Btnadd = Button(command=add_emp, text="Add Details",height=2,width=15,bd=0, bg="#4a9fd6", foreground="white")
Btnadd.place(x=250, y=500) 

Btnadd = Button(command=upd_emp, text="Update Details",height=2,width=15,bd=0,  bg="#4a9fd6", foreground="white")
Btnadd.place(x=400, y=500) 

Btnadd = Button(command=del_emp, text="Delete Details",height=2,width=15,bd=0,  bg="#4a9fd6", foreground="white")
Btnadd.place(x=550, y=500) 

Btnadd = Button(command=cl_emp, text="Clear Details",height=2,width=15,bd=0,  bg="#4a9fd6", foreground="white")
Btnadd.place(x=700, y=500) 

tree_fr=Frame(win)
tree_fr.place(x=45, y=570, width=1450, height=260)
style= ttk.Style()
style.configure("mystyle.Treeview", font=("Tahoma",12))
style.configure("mystyle.Treeview.Heading", font=("Tahoma",12,"bold"))


tv=ttk.Treeview(tree_fr, columns=(1,2,3,4,5,6,7,8),style="mystyle.Treeview")
tv.heading("1", text="ID")
tv.column("1", width=90)
tv.heading("2", text="Name")
tv.heading("3", text="Age")
tv.column("3", width=90)
tv.heading("4", text="D.O.J")
tv.heading("5", text="EMAIL")
tv.heading("6", text="GENDER")
tv.heading("7", text="PH NO")
tv.heading("8", text="ADDRESS")
tv['show']='headings'
tv.bind("<ButtonRelease-1>", getdata)
tv.pack(fill=X)



disp_all()
win.mainloop()
