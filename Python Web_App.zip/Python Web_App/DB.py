import mysql.connector

con=mysql.connector.connect(host="localhost", user="root", passwd="4728", database="employee")

res=con.cursor()
class Database:
    def insert(self,name,age,doj,email,gender,ph,address):
        res.execute("INSERT INTO users (Name, Age, DOJ, EMAIL, GENDER, PH_NO, ADDRESS) VALUES (%s, %s, %s, %s, %s, %s, %s)",
            (name, age, doj, email, gender, ph, address))
        con.commit()
    def fetch(self):
        res.execute("SELECT * FROM USERS")
        rows=res.fetchall()
        return rows
        con.commit()
    def remove(self,id):
        res.execute("DELETE FROM USERS WHERE ID=%s",(id,))
        con.commit()
    def update(self,id,name,age,doj,email,gender,ph,address):
        res.execute("UPDATE users SET Name=%s, Age=%s, DOJ=%s, EMAIL=%s, GENDER=%s, PH_NO=%s, ADDRESS=%s WHERE ID=%s",
            (name, age, doj, email, gender, ph, address, id))
        con.commit()
    def delete(self):
        res.execute("DELETE FROM users")
        con.commit()
obj = Database()